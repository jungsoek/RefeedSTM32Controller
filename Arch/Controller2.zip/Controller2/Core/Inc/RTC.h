#include "stm32f1xx_hal.h"
#include "main.h"

uint8_t Set_RTC(uint8_t Hours, uint8_t Minutes, uint8_t Seconds);
uint8_t Set_Alarm(uint8_t Hours, uint8_t Minutes, uint8_t Seconds);
