 /*
 * Ultrasonic.h
 *
 *  Created on: Aug 25, 2025
 *      Author: Lazy
 */

#ifndef INC_ULTRASONIC_H_
#define INC_ULTRASONIC_H_

float Ultra_ReadDistance(void);

#endif /* INC_ULTRASONIC_H_ */
