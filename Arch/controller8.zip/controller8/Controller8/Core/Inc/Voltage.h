/*
 * Voltage.h
 *
 *  Created on: Sep 4, 2025
 *      Author: Lazy
 */

#ifndef INC_VOLTAGE_H_
#define INC_VOLTAGE_H_

float Read_Voltage(void);

#endif /* INC_VOLTAGE_H_ */
